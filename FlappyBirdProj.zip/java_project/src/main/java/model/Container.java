package main.java.model;
import main.java.logic.*;

public interface Container {
    public Iterator getIterator();
}
