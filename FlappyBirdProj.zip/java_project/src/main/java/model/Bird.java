package main.java.model;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bird {
    private static int y = 200;
    private static int x = 100;
    private BufferedImage bird;



    //otrzymac wartosc x
    public int getX() {
        return x;
    }

    //otrzymac wartosc y
    public int getY() {
        return y;
    }


    public void paint(Graphics g) {
        try {
            //g.setColor(Color.red);
            //g.fillRect(x, y, 45, 45);

            bird = ImageIO.read(new File("img\\Bird.png"));
            g.drawImage(bird, x, y, null);
        } catch (Exception ex) {
            Logger.getLogger(Bird.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    public void birdDown() {
        y++;
    }


    public boolean birdUp() {

        y -= 40;
        return true;

    }

}
