package main.java.model;

import java.awt.*;

public interface Column {

    public int getX();
    public int getH();
    public void randHeight();
    public abstract void paint(Graphics g);
    public void decrementX();
    public void replayX();

}
