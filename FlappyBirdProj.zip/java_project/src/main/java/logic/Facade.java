package main.java.logic;
import main.java.model.*;

import java.awt.*;

public class Facade {
    private static Facade _instance = null;

    ColumnsRepository colRepository;
    Bird bird;
    GameOver gameover1;
    Score score;

    private Facade() {
        colRepository = new ColumnsRepository();
        bird = new Bird();
        gameover1 = new GameOver();
        score = new Score();
    }

    public static synchronized Facade getInstance() {
        if (_instance == null)
            _instance = new Facade();
        return _instance;
    }


    public Iterator getIterator(){
        return colRepository.getIterator();

    }

    public void birdDown() {
        bird.birdDown();

    }

    public void countScore() {
        score.countScore();

    }

    public boolean check() {
        return gameover1.check();
    }

    public int getScr() {
        return score.getScr();
    }


    public void birdPaint(Graphics g) {
        bird.paint(g);

    }

    public int birdGetY() {
        // TODO Auto-generated method stub
        return bird.getY();
    }

    public int birdGetX() {
        // TODO Auto-generated method stub
        return bird.getX();
    }

    public void birdUp() {
        // TODO Auto-generated method stub
        bird.birdUp();
    }
}
