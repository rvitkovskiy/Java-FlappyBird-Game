package main.java;
import main.java.logic.*;
import main.java.model.*;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {
    private static final long serialVersionUID = 1L;
    private Activity action = new Activity();
    //private Bird bird = new Bird();
    JButton okButton = new JButton("OK");
    public Main() {
        setSize(500, 500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(400, 100);
        setResizable(false);

        add(okButton);
        add(action);

        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
                //if (Facade.getInstance().bird.getY() >= 0) {
                Facade.getInstance().birdUp();
                //}
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (Facade.getInstance().birdGetY() >= 0) {
                    Facade.getInstance().birdUp();
                }
            }
        });
    }

    public static void main(String[] args) {
        Main flappy = new Main();

    }
}
